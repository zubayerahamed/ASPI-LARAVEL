<div class="card card-default">
    <div class="card-body">
        <form action="">
            <input type="hidden" name="id">

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="name">Category name</label>
                        <input type="text" class="form-control" id="name" name="name">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="xcode">Category code</label>
                        <input type="text" class="form-control" id="xcode" name="xcode">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="is_active">Is Active?</label>
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="is_active" name="is_active">
                        </div>
                    </div>

                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <button type="reset" data-reloadid="main-form-container" data-reloadurl="/SO05?id=RESET" class="btn btn-default btn-reset">Clear</button>
                </div>
                <div>
                    <button type="submit" class="btn btn-primary btn-submit">Add</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        kit.ui.init();

        $('.btn-reset').off('click').on('click', function(e) {
            e.preventDefault();

            sectionReloadAjaxReq({
                id: $(this).data('reloadid'),
                url: $(this).data('reloadurl')
            });
        });

        $('.btn-submit').off('click').on('click', function(e) {
            e.preventDefault();
            submitMainForm();
        });

        $('.btn-delete').off('click').on('click', function(e) {
            e.preventDefault();
            if (!confirm("Are you sure, to delete this?")) {
                return;
            }
            deleteRequest($(this).data('url'));
        });

        $('.btn-confirm').off('click').on('click', function(e) {
            e.preventDefault();
            if (!confirm("Are you sure?")) {
                return;
            }
            actionPostRequest($(this).data('url'));
        });
    })
</script>
<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/SA05/SO05-main-form.blade.php ENDPATH**/ ?>