<?php if(!$detailList->isEmpty()): ?>
    <div class="card card-default">

        <div class="card-header">
            <h3 class="card-title">List of pages</h3>
        </div>

        <div class="table-responsive data-table-responsive">
            <table class="table table-hover table-bordered p-0 m-0 datatable-fragment">
                <thead>
                    <tr>
                        <th>Page Code</th>
                        <th>Title</th>
                        <th>Type</th>
                        <th class="text-center">Sequence</th>
                        <th>Icon</th>
                        <th class="text-right" data-no-sort="Y">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $detailList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a data-reloadurl="<?php echo e(route('SA04', ['id' => $x->id])); ?>" class="detail-dataindex" data-reloadid="main-form-container" href="#"><?php echo e($x->xscreen); ?></a>
                            </td>
                            <td><?php echo e($x->title); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($x->type == 'SCREEN' ? 'primary' : ($x->type == 'REPORT' ? 'success' : ($x->type == 'SYSTEM' ? 'info' : 'warning'))); ?>"><?php echo e($x->type); ?></span>
                            </td>
                            <td class="text-center"><?php echo e($x->seqn); ?></td>
                            <td><?php echo e($x->icon); ?></td>
                            <td>
                                <div class="d-flex justify-content-end align-items-center gap-2">
                                    <button data-url="<?php echo e(route('SA04.delete', ['id' => $x->id])); ?>" type="button" class="btn btn-sm btn-danger btn-table-delete d-flex align-items-center">
                                        <i class="ph ph-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            kit.ui.config.initDatatable('datatable-fragment');

            $('.datatable-fragment').on('click', 'a.detail-dataindex', function(e){
                e.preventDefault();

                sectionReloadAjaxReq({
                    id: $(this).data('reloadid'),
                    url: $(this).data('reloadurl')
                });
            });

            $('.datatable-fragment').on('click', 'button.btn-table-delete', function(e){
                e.preventDefault();
                sweetAlertConfirm(() => {
                    deleteRequest($(this).data('url'));
                });
            });
        })
    </script>
<?php endif; ?>
<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/SA04/SA04-header-table.blade.php ENDPATH**/ ?>