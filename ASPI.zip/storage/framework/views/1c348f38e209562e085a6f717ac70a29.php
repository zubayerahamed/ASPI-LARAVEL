<div class="card card-default">
    <!-- form start -->

    <div class="card-body">
        <form action="">
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="name">Category name</label>
                        <input type="text" class="form-control" id="name" name="name">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="xcode">Category code</label>
                        <input type="text" class="form-control" id="xcode" name="xcode">
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="is_active">Is Active?</label>
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input" id="is_active" name="is_active">
                        </div>
                    </div>

                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <button type="reset" class="btn btn-default btn-reset">Clear</button>
                </div>
                <div>
                    <button type="submit" class="btn btn-primary btn-submit">Add</button>
                </div>
            </div>
        </form>
    </div>
    <!-- /.card-body -->

</div>
<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/SA05/SO15-main-form.blade.php ENDPATH**/ ?>