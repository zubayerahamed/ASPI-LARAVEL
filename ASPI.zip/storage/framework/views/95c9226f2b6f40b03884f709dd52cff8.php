<div class="col-md-12">
    hi there
</div>

<?php echo $__env->make("pages.examples", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<script>
    $(document).ready(function() {
        kit.ui.init();
    });
</script>

<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>