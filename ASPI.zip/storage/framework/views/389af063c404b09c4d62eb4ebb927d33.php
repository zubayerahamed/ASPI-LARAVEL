<?php if(!$detailList->isEmpty()): ?>
    <div class="card card-default">

        <div class="card-header">
            <h3 class="card-title">List of attributes</h3>
        </div>

        <div class="table-responsive data-table-responsive">
            <table class="table table-hover table-bordered p-0 m-0 datatable-fragment">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Options</th>
                        <th class="text-center">Sequence</th>
                        <th class="text-center">Is Active?</th>
                        <th class="text-right" data-no-sort="Y">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $detailList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a data-reloadurl="<?php echo e(route('AD04', ['id' => $x->id])); ?>" class="detail-dataindex" data-reloadid="main-form-container" href="#"><?php echo e($x->name); ?></a>
                            </td>
                            <td>
                                <div>
                                    <?php $__currentLoopData = $x->terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="p-0 m-0 text-sm text-muted"><?php echo e($term->name); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <a href="<?php echo e(route('AD05', ['attribute_id' => $x->id])); ?>" class="text-sm screen-item" data-screen="AD05?attribute_id=<?php echo e($x->id); ?>">Configure Terms</a>
                            </td>
                            <td class="text-center"><?php echo e($x->seqn); ?></td>
                            <td class="text-center">
                                <?php if($x->is_active): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="d-flex justify-content-end align-items-center gap-2">
                                    <button data-url="<?php echo e(route('AD04.delete', ['id' => $x->id])); ?>" type="button" class="btn btn-sm btn-danger btn-table-delete d-flex align-items-center">
                                        <i class="ph ph-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            kit.ui.config.initDatatable('datatable-fragment');

            $('.datatable-fragment').on('click', 'a.detail-dataindex', function(e){
                e.preventDefault();

                sectionReloadAjaxReq({
                    id: $(this).data('reloadid'),
                    url: $(this).data('reloadurl')
                });
            });

            $('.datatable-fragment').on('click', 'button.btn-table-delete', function(e){
                e.preventDefault();
                sweetAlertConfirm(() => {
                    deleteRequest($(this).data('url'));
                });
            });
        })
    </script>
<?php endif; ?>
<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/AD04/AD04-header-table.blade.php ENDPATH**/ ?>