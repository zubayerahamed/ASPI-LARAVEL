<?php $__env->startSection('title'); ?>
    <?php echo e(config('adminlte.title')); ?>

    <?php if (! empty(trim($__env->yieldContent('subtitle')))): ?>
        | <?php echo $__env->yieldContent('subtitle'); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/kit-ui.css')); ?>" />
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content_header'); ?>
    <?php if (! empty(trim($__env->yieldContent('content_header_title')))): ?>
        <h1 class="text-muted content_header_title">
            <?php echo $__env->yieldContent('content_header_title'); ?>

            <?php if (! empty(trim($__env->yieldContent('content_header_subtitle')))): ?>
                <small class="text-dark">
                    <i class="fas fa-xs fa-angle-right text-muted"></i>
                    <?php echo $__env->yieldContent('content_header_subtitle'); ?>
                </small>
            <?php endif; ?>
        </h1>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('home')); ?>" class="basePath"></a>
    <a href="<?php echo e(route('AD18.create')); ?>" class="filepond-process-url"></a>
    <a href="<?php echo e(route('AD18.destroy')); ?>" class="filepond-revert-url"></a>

    <?php echo $__env->yieldContent('content_body'); ?>

    
    <?php echo $__env->make('partials.loading-mask', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('preloader'); ?>
    <?php echo $__env->make('partials.preloader-mask', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <div class="float-right">
        Version: <?php echo e(config('app.version', '1.0.0')); ?>

    </div>

    <strong>
        Copyright &copy; <?php echo e(date('Y')); ?>

        <a href="<?php echo e(config('app.company_url', 'https://www.zayaanit.com')); ?>" target="_blank">
            <?php echo e(config('app.company_name', 'ZAYAAN IT')); ?>

        </a>
    </strong>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/js/kit-functions.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/kit-ui.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/layouts/app.blade.php ENDPATH**/ ?>