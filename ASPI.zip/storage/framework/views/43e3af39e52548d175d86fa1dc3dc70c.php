<div class="card card-default">
    <div class="card-body">
        <form id="mainform" action="<?php echo e($business->id == null ? route('SA10.create') : route('SA10.update', ['id' => $business->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if($business->id != null): ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="id" value="<?php echo e($business->id); ?>">
            <?php endif; ?>

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="business_category_id">Business Category</label>
                        <select class="form-control select2bs4" id="business_category_id" name="business_category_id" required>
                            <option value="">-- Select Category --</option>
                            <?php $__currentLoopData = $businessCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($bc->id); ?>" <?php echo e($business->business_category_id == $bc->id ? 'selected' : ''); ?>><?php echo e($bc->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="name">Business name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($business->name); ?>" required>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="email">Business email</label>
                        <input type="text" class="form-control" id="email" name="email" value="<?php echo e($business->email); ?>" required>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="mobile">Business Mobile</label>
                        <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo e($business->mobile); ?>" required>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="country">Business Country</label>
                        <select class="form-control select2bs4" id="country" name="country" required>
                            <option value="">-- Select Country --</option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country['code']); ?>" <?php echo e($business->country == $country['code'] ? 'selected' : ''); ?>><?php echo e($country['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="currency">Business Currency</label>
                        <select class="form-control select2bs4" id="currency" name="currency" required>
                            <option value="">-- Select Currency --</option>
                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($currency['code']); ?>" <?php echo e($business->currency == $currency['code'] ? 'selected' : ''); ?>><?php echo e($currency['name']); ?> (<?php echo e($currency['symbol']); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="form-group mb-3">
                        <label class="form-label d-block" for="is_active">Is Active?</label>
                        <input type="checkbox" id="is_active" name="is_active" <?php echo e($business->is_active ? 'checked' : ''); ?>>
                    </div>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-md-12">
                    <h4 class="m-0">Select Services</h4>
                    <span class="text-muted">Atleast one service must be selected</span>
                    <hr>
                </div>
                <div class="col-md-3">
                    <div class="form-group mb-3">
                        <label class="form-label d-block" for="is_inhouse">Is Inhouse?</label>
                        <input type="checkbox" id="is_inhouse" name="is_inhouse" <?php echo e($business->is_inhouse ? 'checked' : ''); ?>>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group mb-3">
                        <label class="form-label d-block" for="is_pickup">Is Pickup?</label>
                        <input type="checkbox" id="is_pickup" name="is_pickup" <?php echo e($business->is_pickup ? 'checked' : ''); ?>>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group mb-3">
                        <label class="form-label d-block" for="is_delivery">Is Delivery?</label>
                        <input type="checkbox" id="is_delivery" name="is_delivery" <?php echo e($business->is_delivery ? 'checked' : ''); ?>>
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center">
                <div class="flex-grow-1 text-left">
                    <button 
                        data-reloadid="main-form-container" 
                        data-reloadurl="<?php echo e(route('SA10', ['id' => 'RESET'])); ?>" 
                        data-detailreloadid="header-table-container" 
                        data-detailreloadurl="<?php echo e(route('SA10.header-table')); ?>"
                        type="reset" 
                        class="btn btn-sm btn-default btn-reset d-flex align-items-center gap-2">
                        <i class="ph ph-broom"></i> <span>Clear</span>
                    </button>
                </div>
                <div class="flex-grow-1 justify-content-end d-flex gap-2">
                    <?php if($business->id == null): ?>
                        <button type="submit" class="btn btn-sm btn-primary btn-submit d-flex align-items-center gap-2">
                            <i class="ph ph-floppy-disk"></i> <span>Save</span>
                        </button>
                    <?php else: ?>
                        <button data-url="<?php echo e(route('SA10.delete', ['id' => $business->id])); ?>" type="button"  class="btn btn-sm btn-danger btn-delete d-flex align-items-center gap-2">
                            <i class="ph ph-trash"></i> <span>Delete</span>
                        </button>
                        <button type="submit" class="btn btn-sm btn-primary btn-submit d-flex align-items-center gap-2">
                            <i class="ph ph-floppy-disk"></i> <span>Update</span>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        kit.ui.init();

        $('.btn-reset').off('click').on('click', function(e) {
            e.preventDefault();

            sectionReloadAjaxReq({
                id: $(this).data('reloadid'),
                url: $(this).data('reloadurl')
            });

            sectionReloadAjaxReq({
                id: $(this).data('detailreloadid'),
                url: $(this).data('detailreloadurl')
            });
        });

        $('.btn-submit').off('click').on('click', function(e) {
            e.preventDefault();
            submitMainForm();
        });

        $('.btn-delete').off('click').on('click', function(e) {
            e.preventDefault();
            if (!confirm("Are you sure, to delete this?")) {
                return;
            }
            deleteRequest($(this).data('url'));
        });
    })
</script>
<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/SA10/SA10-main-form.blade.php ENDPATH**/ ?>