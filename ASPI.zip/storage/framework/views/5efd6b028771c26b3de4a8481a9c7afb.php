<div class="card card-default">

    <div class="card-header">
        <h3 class="card-title">Business Categories List</h3>
    </div>

    <div class="card-body">

    </div>

</div>
<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/SA05/SO05-header-table.blade.php ENDPATH**/ ?>