<div class="row">
    <div class="col-md-4">
        <div class="main-form-container">
            <?php echo $__env->make('pages.AD05.AD05-main-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <div class="col-md-8">
        <div class="header-table-container">
            <?php echo $__env->make('pages.AD05.AD05-header-table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</div><?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/AD05/AD05.blade.php ENDPATH**/ ?>