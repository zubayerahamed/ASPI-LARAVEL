<div class="card card-default">
    <div class="card-body">
        <form id="mainform" action="<?php echo e($user->id == null ? route('SA03.create') : route('SA03.update', ['id' => $user->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if($user->id != null): ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
            <?php endif; ?>

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="email">User Email</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" required>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="country">Businesses</label>
                        <select class="form-control select2bs4" id="business_ids" name="business_ids[]" multiple required>
                            <option value="">-- Select Business --</option>
                            <?php $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($business->id); ?>" <?php echo e($user->businesses && $user->businesses->contains('id', $business->id) ? 'selected' : ''); ?>><?php echo e($business->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <?php if($user->id != null): ?>
                    <div class="col-md-3">
                        <div class="form-group mb-3">
                            <label class="form-label d-block" for="is_active">Is Active?</label>
                            <input type="checkbox" id="is_active" name="is_active" <?php echo e($user->status == 'active' ? 'checked' : ''); ?>>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="d-flex justify-content-between align-items-center">
                <div class="flex-grow-1 text-left">
                    <button
                            data-reloadid="main-form-container"
                            data-reloadurl="<?php echo e(route('SA03', ['id' => 'RESET'])); ?>"
                            data-detailreloadid="header-table-container"
                            data-detailreloadurl="<?php echo e(route('SA03.header-table')); ?>"
                            type="reset"
                            class="btn btn-sm btn-default btn-reset d-flex align-items-center gap-2">
                        <i class="ph ph-broom"></i> <span>Clear</span>
                    </button>
                </div>
                <div class="flex-grow-1 justify-content-end d-flex gap-2">
                    <?php if($user->id == null): ?>
                        <button type="submit" class="btn btn-sm btn-primary btn-submit d-flex align-items-center gap-2">
                            <i class="ph ph-floppy-disk"></i> <span>Save</span>
                        </button>
                    <?php else: ?>
                        <button data-url="<?php echo e(route('SA03.delete', ['id' => $user->id])); ?>" type="button" class="btn btn-sm btn-danger btn-delete d-flex align-items-center gap-2">
                            <i class="ph ph-trash"></i> <span>Delete</span>
                        </button>
                        <button type="submit" class="btn btn-sm btn-primary btn-submit d-flex align-items-center gap-2">
                            <i class="ph ph-floppy-disk"></i> <span>Update</span>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        kit.ui.init();

        $('.btn-reset').off('click').on('click', function(e) {
            e.preventDefault();

            sectionReloadAjaxReq({
                id: $(this).data('reloadid'),
                url: $(this).data('reloadurl')
            });

            sectionReloadAjaxReq({
                id: $(this).data('detailreloadid'),
                url: $(this).data('detailreloadurl')
            });
        });

        $('.btn-submit').off('click').on('click', function(e) {
            e.preventDefault();
            submitMainForm();
        });

        $('.btn-delete').off('click').on('click', function(e) {
            e.preventDefault();
            sweetAlertConfirm(() => {
                deleteRequest($(this).data('url'));
            });
        });
    })
</script>
<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/SA03/SA03-main-form.blade.php ENDPATH**/ ?>