<?php $__env->startSection('subtitle'); ?>
    Home
<?php $__env->stopSection(); ?>

Home Page<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/home.blade.php ENDPATH**/ ?>