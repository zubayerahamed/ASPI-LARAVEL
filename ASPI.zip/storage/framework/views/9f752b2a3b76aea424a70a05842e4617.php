<?php if(!$detailList->isEmpty()): ?>
    <div class="card card-default">

        <div class="card-header">
            <h3 class="card-title">Business Admins List</h3>
        </div>

        <div class="table-responsive data-table-responsive">
            <table class="table table-hover table-bordered p-0 m-0 datatable-fragment">
                <thead>
                    <tr>
                        <th>Email</th>
                        <th>Name</th>
                        <th>Businesses</th>
                        <th class="text-center">Status</th>
                        <th class="text-right">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $detailList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a data-reloadurl="<?php echo e(route('SA15', ['id' => $x->id])); ?>" class="detail-dataindex" data-reloadid="main-form-container" href="#"><?php echo e($x->email); ?></a>
                            </td>
                            <td><?php echo e($x->name); ?></td>
                            <td>
                                <?php $__currentLoopData = $x->businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-primary"><?php echo e($business->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td class="text-center"><?php echo e($x->status); ?></td>
                            <td class="d-flex justify-content-end gap-2">
                                <button data-url="<?php echo e(route('SA15.delete', ['id' => $x->id])); ?>" type="button" class="btn btn-sm btn-danger btn-table-delete d-flex align-items-center">
                                    <i class="ph ph-trash"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            kit.ui.config.initDatatable('datatable-fragment');

            $('a.detail-dataindex').off('click').on('click', function(e) {
                e.preventDefault();

                sectionReloadAjaxReq({
                    id: $(this).data('reloadid'),
                    url: $(this).data('reloadurl')
                });
            });

            $('.btn-table-delete').off('click').on('click', function(e) {
                e.preventDefault();
                if (!confirm("Are you sure, to delete this?")) {
                    return;
                }
                deleteRequest($(this).data('url'));
            });
        })
    </script>
<?php endif; ?>
<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/SA15/SA15-header-table.blade.php ENDPATH**/ ?>