<div class="row">
    <div class="col-md-4">
        <div class="main-form-container">
            <?php echo $__env->make('pages.AD04.AD04-main-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <div class="col-md-8">
        <div class="header-table-container">
            <?php echo $__env->make('pages.AD04.AD04-header-table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</div><?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/AD04/AD04.blade.php ENDPATH**/ ?>