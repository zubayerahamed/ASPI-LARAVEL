<?php $__currentLoopData = $menuTree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $indent = str_repeat('|&nbsp;&nbsp;&nbsp;&nbsp;', $count) . '|--';
    ?>
    <option value="<?php echo e($m['id']); ?>" <?php echo e($menu->parent_menu_id == $m['id'] ? 'selected' : ''); ?>><?php echo $indent . $m['xmenu'] . ' - ' . $m['title']; ?></option>
    <?php if(!empty($m['children'])): ?>
        <?php echo $__env->make('pages.SA05.SA05-category-recursive', [
            'menuTree' => $m['children'],
            'count' => $count + 1
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/SA05/SA05-category-recursive.blade.php ENDPATH**/ ?>