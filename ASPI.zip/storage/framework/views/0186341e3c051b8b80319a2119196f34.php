<div>
    <div id="loadingmask2">
        <div id="loadingdots">
            <div id="loadingdots_1" class="loadingdots">L</div>
            <div id="loadingdots_2" class="loadingdots">O</div>
            <div id="loadingdots_3" class="loadingdots">A</div>
            <div id="loadingdots_4" class="loadingdots">D</div>
            <div id="loadingdots_5" class="loadingdots">I</div>
            <div id="loadingdots_6" class="loadingdots">N</div>
            <div id="loadingdots_7" class="loadingdots">G</div>
        </div>
    </div>
</div>
<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/partials/preloader-mask.blade.php ENDPATH**/ ?>