<div class="row">
    <div class="d-flex justify-content-center flex-wrap" style="width: 100%;">
        <?php $__currentLoopData = $businesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $business): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <a href="<?php echo e(route('business.selection', ['id' => $business->id])); ?>" class="d-block business-card text-center pt-4 pb-4 p-3 mb-4 border rounded bg-primary text-white cursor-pointer">
                    <h4><?php echo e($business->name); ?></h4>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/business-selection.blade.php ENDPATH**/ ?>