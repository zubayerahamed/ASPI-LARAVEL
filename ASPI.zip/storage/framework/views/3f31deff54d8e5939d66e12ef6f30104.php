<?php if(isset($detailList) && count($detailList) > 0): ?>
    <div class="card card-default">

        <div class="card-header">
            <h3 class="card-title">Navigations with assigned Screens</h3>
        </div>

        <div class="card-body datatable-fragment">
            <?php $__currentLoopData = $detailList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p style="font-size: 20px; font-weight: bold"><?php echo e($x['xmenu'] . ' - ' . $x['title']); ?></p>
                <!-- Print assigned screens -->
                <?php $__currentLoopData = $x['menu_screens']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p style="margin-left: 50px;">
                        <a class="detail-dataindex" href="#" data-reloadid="main-form-container" data-reloadurl="<?php echo e(route('SA06', ['id' => $screen['id']])); ?>"><?php echo e($screen['screen_xscreen']); ?></a> - <?php echo e($screen['alternate_title']); ?>

                        <?php if($screen['screen_type'] == 'Screen'): ?>
                            <span class="ml-2 badge bg-primary"><?php echo $screen['screen_type']; ?></span>
                        <?php else: ?>
                            <span class="ml-2 badge bg-success"><?php echo $screen['screen_type']; ?></span>
                        <?php endif; ?>
                        <span class="ml-2 badge bg-warning"><?php echo 'SN. ' . $screen['seqn']; ?></span>
                        <a href="" class="ml-2 badge bg-danger btn-table-delete" data-url="<?php echo e(route('SA06.delete', ['id' => $screen['id']])); ?>"><i class="ph ph-trash"></i></a>
                    </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- Print Child Menus recursively -->
                <?php if(isset($x['children']) && count($x['children']) > 0): ?>
                    <?php echo $__env->make('pages.SA06.SA06-header-table-children', ['children' => $x['children'], 'margin' => 50], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            $('.datatable-fragment').on('click', 'a.detail-dataindex', function(e) {
                e.preventDefault();

                sectionReloadAjaxReq({
                    id: $(this).data('reloadid'),
                    url: $(this).data('reloadurl')
                });
            });

            $('.datatable-fragment').on('click', 'a.btn-table-delete', function(e) {
                e.preventDefault();
                if (!confirm("Are you sure, to delete this?")) {
                    return;
                }
                deleteRequest($(this).data('url'));
            });
        })
    </script>
<?php endif; ?>
<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/SA06/SA06-header-table.blade.php ENDPATH**/ ?>