<?php if(!$detailList->isEmpty()): ?>
    <div class="card card-default">

        <div class="card-header">
            <h3 class="card-title">List of Codes & Parameters</h3>
        </div>

        <div class="table-responsive data-table-responsive">
            <table class="table table-hover table-bordered p-0 m-0 datatable-fragment">
                <thead>
                    <tr>
                        <th>Code Type</th>
                        <th>Code</th>
                        <th>Description</th>
                        <th class="text-center">Sequence</th>
                        <th class="text-right" data-no-sort="Y">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $detailList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <a data-reloadurl="<?php echo e(route('SA05', ['id' => $x->id])); ?>" class="detail-dataindex" data-reloadid="main-form-container" href="#"><?php echo e($x->type); ?></a>
                            </td>
                            <td><?php echo e($x->xcode); ?></td>
                            <td><?php echo e($x->description); ?></td>
                            <td class="text-center"><?php echo e($x->seqn); ?></td>
                            <td>
                                <div class="d-flex justify-content-end align-items-center gap-2">
                                    <button data-url="<?php echo e(route('SA05.delete', ['id' => $x->id])); ?>" type="button" class="btn btn-sm btn-danger btn-table-delete d-flex align-items-center">
                                        <i class="ph ph-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

    </div>

    <script type="text/javascript">
        $(document).ready(function() {
            kit.ui.config.initDatatable('datatable-fragment');

            $('.datatable-fragment').on('click', 'a.detail-dataindex', function(e){
                e.preventDefault();

                sectionReloadAjaxReq({
                    id: $(this).data('reloadid'),
                    url: $(this).data('reloadurl')
                });
            });

            $('.datatable-fragment').on('click', 'button.btn-table-delete', function(e){
                e.preventDefault();
                sweetAlertConfirm(() => {
                    deleteRequest($(this).data('url'));
                });
            });
        })
    </script>
<?php endif; ?>
<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/SA05/SA05-header-table.blade.php ENDPATH**/ ?>