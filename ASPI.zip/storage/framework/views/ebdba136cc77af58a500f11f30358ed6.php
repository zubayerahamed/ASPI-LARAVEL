<div class="card card-default">
    <div class="card-body">
        <form id="mainform" action="<?php echo e($menuScreen->id == null ? route('SA06.create') : route('SA06.update', ['id' => $menuScreen->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if($menuScreen->id != null): ?>
                <?php echo method_field('PUT'); ?>
                <input type="hidden" name="id" value="<?php echo e($menuScreen->id); ?>">
            <?php endif; ?>

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="menu_id">Menu</label>
                        <select class="form-control select2bs4" id="menu_id" name="menu_id" required>
                            <option value="">-- Select Menu --</option>
                            <?php echo $__env->make('pages.SA06.SA06-menu-recursive', [
                                'menuTree' => $menus,
                                'count' => 0,
                            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label class="form-label" for="screen_id">Screen/Report</label>
                        <select class="form-control select2bs4" id="screen_id" name="screen_id" required>
                            <option value="">-- Select Screen --</option>
                            <?php $__currentLoopData = $screens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $screen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($screen->id); ?>" <?php echo e($menuScreen->screen_id == $screen->id ? 'selected' : ''); ?>><?php echo e($screen->xscreen); ?> - <?php echo e($screen->title); ?> - <?php echo e($screen->type); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group mb-3">
                        <label class="form-label" for="alternate_title">Alternate Title</label>
                        <input type="text" class="form-control" id="alternate_title" name="alternate_title" value="<?php echo e($menuScreen->alternate_title); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group mb-3">
                        <label class="form-label" for="seqn">Sequence number</label>
                        <input type="number" class="form-control" id="seqn" name="seqn" value="<?php echo e($menuScreen->seqn); ?>" min="0">
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center">
                <div class="flex-grow-1 text-left">
                    <button
                            data-reloadid="main-form-container"
                            data-reloadurl="<?php echo e(route('SA06', ['id' => 'RESET'])); ?>"
                            data-detailreloadid="header-table-container"
                            data-detailreloadurl="<?php echo e(route('SA06.header-table')); ?>"
                            type="reset"
                            class="btn btn-sm btn-default btn-reset d-flex align-items-center gap-2">
                        <i class="ph ph-broom"></i> <span>Clear</span>
                    </button>
                </div>
                <div class="flex-grow-1 justify-content-end d-flex gap-2">
                    <?php if($menuScreen->id == null): ?>
                        <button type="submit" class="btn btn-sm btn-primary btn-submit d-flex align-items-center gap-2">
                            <i class="ph ph-floppy-disk"></i> <span>Save</span>
                        </button>
                    <?php else: ?>
                        <button data-url="<?php echo e(route('SA06.delete', ['id' => $menuScreen->id])); ?>" type="button" class="btn btn-sm btn-danger btn-delete d-flex align-items-center gap-2">
                            <i class="ph ph-trash"></i> <span>Delete</span>
                        </button>
                        <button type="submit" class="btn btn-sm btn-primary btn-submit d-flex align-items-center gap-2">
                            <i class="ph ph-floppy-disk"></i> <span>Update</span>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        kit.ui.init();

        $('.btn-reset').off('click').on('click', function(e) {
            e.preventDefault();

            sectionReloadAjaxReq({
                id: $(this).data('reloadid'),
                url: $(this).data('reloadurl')
            });

            sectionReloadAjaxReq({
                id: $(this).data('detailreloadid'),
                url: $(this).data('detailreloadurl')
            });
        });

        $('.btn-submit').off('click').on('click', function(e) {
            e.preventDefault();
            submitMainForm();
        });

        $('.btn-delete').off('click').on('click', function(e) {
            e.preventDefault();
            if (!confirm("Are you sure, to delete this?")) {
                return;
            }
            deleteRequest($(this).data('url'));
        });
    })
</script>
<?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/SA06/SA06-main-form.blade.php ENDPATH**/ ?>