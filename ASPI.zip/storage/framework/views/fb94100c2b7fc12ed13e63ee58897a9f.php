<?php $__env->startSection('subtitle'); ?>
    <?php echo e($subtitle); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_header_title'); ?>
    <?php echo e($content_header_title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_body'); ?>
    <div class="screen-container">
        <?php if($page): ?>
            <?php echo $__env->make($page, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/index.blade.php ENDPATH**/ ?>