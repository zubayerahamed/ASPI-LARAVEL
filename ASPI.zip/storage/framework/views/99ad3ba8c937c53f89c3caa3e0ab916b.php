<div class="row">
    <div class="col-md-12">
        <div class="main-form-container">
            <?php echo $__env->make('pages.SA03.SA03-main-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="header-table-container">
            <?php echo $__env->make('pages.SA03.SA03-header-table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</div><?php /**PATH E:\laravel-ws\ASPI-LARAVEL\resources\views/pages/SA03/SA03.blade.php ENDPATH**/ ?>