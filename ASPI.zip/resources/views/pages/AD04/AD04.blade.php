<div class="row">
    <div class="col-md-4">
        <div class="main-form-container">
            @include('pages.AD04.AD04-main-form')
        </div>
    </div>

    <div class="col-md-8">
        <div class="header-table-container">
            @include('pages.AD04.AD04-header-table')
        </div>
    </div>
</div>