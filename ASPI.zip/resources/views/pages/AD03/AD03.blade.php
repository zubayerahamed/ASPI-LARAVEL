<div class="row">
    <div class="col-md-4">
        <div class="main-form-container">
            @include('pages.AD03.AD03-main-form')
        </div>
    </div>

    <div class="col-md-8">
        <div class="header-table-container">
            @include('pages.AD03.AD03-header-table')
        </div>
    </div>
</div>