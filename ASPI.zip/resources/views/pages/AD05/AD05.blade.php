<div class="row">
    <div class="col-md-4">
        <div class="main-form-container">
            @include('pages.AD05.AD05-main-form')
        </div>
    </div>

    <div class="col-md-8">
        <div class="header-table-container">
            @include('pages.AD05.AD05-header-table')
        </div>
    </div>
</div>