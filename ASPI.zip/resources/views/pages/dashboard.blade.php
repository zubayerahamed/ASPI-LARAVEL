<div class="col-md-12">
    hi there
</div>

@include("pages.examples")

<script>
    $(document).ready(function() {
        kit.ui.init();
    });
</script>

