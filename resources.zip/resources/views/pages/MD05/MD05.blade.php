<div class="row">
    @if($allowCustomTags)
        <div class="col-md-4">
            <div class="main-form-container">
                @include('pages.MD05.MD05-main-form')
            </div>
        </div>
    @endif

    <div class="col-md-8">
        <div class="header-table-container">
            @include('pages.MD05.MD05-header-table')
        </div>
    </div>
</div>