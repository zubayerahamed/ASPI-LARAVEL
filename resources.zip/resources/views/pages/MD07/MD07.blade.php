<div class="row">
    <div class="col-md-12">
        <div class="main-form-container">
            @include('pages.MD07.MD07-main-form')
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="detail-table-container">
            @include('pages.MD07.MD07-detail-table')
        </div>
    </div>
</div>