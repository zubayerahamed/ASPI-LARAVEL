<div class="row">
    <div class="col-md-4">
        <div class="main-form-container">
            @include('pages.AD21.AD21-main-form')
        </div>
    </div>

    <div class="col-md-8">
        <div class="header-table-container">
            @include('pages.AD21.AD21-header-table')
        </div>
    </div>
</div>