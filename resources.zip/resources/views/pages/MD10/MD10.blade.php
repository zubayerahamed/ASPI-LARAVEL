<div class="row">
    <div class="col-md-12">
        <div class="main-form-container">
            @include('pages.MD10.MD10-main-form')
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="header-table-container">
            @include('pages.MD10.MD10-header-table')
        </div>
    </div>
</div>
