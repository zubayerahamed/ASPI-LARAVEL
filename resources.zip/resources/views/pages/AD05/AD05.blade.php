<div class="row">
    <div class="col-md-12">
        <div class="main-form-container">
            @include('pages.AD05.AD05-main-form')
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="detail-table-container">
            @include('pages.AD05.AD05-detail-table')
        </div>
    </div>
</div>