<div class="row">
    <div class="col-md-12">
        <div class="main-form-container">
            @include('pages.MD09.MD09-main-form')
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="detail-table-container">
            @include('pages.MD09.MD09-detail-table')
        </div>
    </div>
</div>