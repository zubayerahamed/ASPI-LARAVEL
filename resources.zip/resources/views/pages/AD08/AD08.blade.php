<div class="row">
    <div class="col-md-12">
        <div class="main-form-container">
            @include('pages.AD08.AD08-main-form')
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="header-table-container">
            @include('pages.AD08.AD08-header-table')
        </div>
    </div>
</div>