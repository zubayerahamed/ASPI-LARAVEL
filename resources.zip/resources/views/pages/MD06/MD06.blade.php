<div class="row">
    @if($allowCustomProductLabels)
        <div class="col-md-4">
            <div class="main-form-container">
                @include('pages.MD06.MD06-main-form')
            </div>
        </div>
    @endif

    <div class="col-md-8">
        <div class="header-table-container">
            @include('pages.MD06.MD06-header-table')
        </div>
    </div>
</div>