<div class="row">
    <div class="col-md-12">
        <div class="main-form-container">
            @include('pages.SA04.SA04-main-form')
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="header-table-container">
            @include('pages.SA04.SA04-header-table')
        </div>
    </div>
</div>