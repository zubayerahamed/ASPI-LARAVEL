@if ($allowCustomMenu)
    <div class="row">
        <div class="col-md-12">
            <div class="main-form-container">
                @include('pages.AD03.AD03-main-form')
            </div>
        </div>
    </div>
@endif

<div class="row">
    <div class="col-md-12">
        <div class="header-table-container">
            @include('pages.AD03.AD03-header-table')
        </div>
    </div>
</div>