<div class="row">
    <div class="col-md-12">
        <div class="main-form-container">
            @include('pages.AD17.AD17-main-form')
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-12">
        <div class="header-table-container">
            @include('pages.AD17.AD17-header-table')
        </div>
    </div>
</div>