// import './bootstrap';

import './plugins/jquery.dataTables.min.js';
import './plugins/dataTables.bootstrap4.min.js';

import './plugins/dataTables.responsive.min.js';
import './plugins/responsive.bootstrap4.min.js';

import './plugins/kit-functions.js';
import './plugins/kit-ui.js';

// import './plugins/dataTables.buttons.min.js';
// import './plugins/buttons.bootstrap4.min.js';

// import './plugins/buttons.html5.min.js';
// import './plugins/buttons.print.min.js';
// import './plugins/buttons.colVis.min.js';
// import './plugins/jszip.min.js';
// import './plugins/pdfmake.min.js';
// import './plugins/vfs_fonts.js';
